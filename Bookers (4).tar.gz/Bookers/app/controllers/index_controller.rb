class IndexController < ApplicationController
  def show
  end

  def new
  end

  def edit
  end
end
